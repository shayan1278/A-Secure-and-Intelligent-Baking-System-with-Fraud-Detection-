
from flask import Blueprint, jsonify, request, render_template, flash, redirect, url_for
from flask_login import login_required, current_user
import logging
from app.services.transaction_service import TransactionService
from app.models import Account
from datetime import datetime
from decimal import Decimal

logger = logging.getLogger(__name__)

transactions_bp = Blueprint('transactions', __name__)

@transactions_bp.route('/', methods=['GET'])
@login_required
def get_transactions():
    try:
        account_id = request.args.get('account_id')
        limit = int(request.args.get('limit', 50))
        offset = int(request.args.get('offset', 0))

        transactions = TransactionService.get_transaction_history(
            current_user.user_id, 
            account_id=account_id,
            limit=limit,
            offset=offset
        )
        
        if request.is_json:
            return jsonify([t.to_dict() for t in transactions]), 200
        accounts = Account.query.filter_by(user_id=current_user.user_id).all()
        return render_template('transactions.html', transactions=transactions, accounts=accounts)
    except Exception as e:
        logger.error(f"Failed to get transactions: {str(e)}")
        if request.is_json:
            return jsonify({'error': str(e)}), 500
        flash('Unable to load transactions', 'danger')
        return redirect(url_for('accounts.dashboard'))

@transactions_bp.route('/create', methods=['POST'])
@login_required
def create_transaction():
    try:
        from_account = request.form.get('from_account')
        to_account = request.form.get('to_account')
        amount = Decimal(request.form.get('amount'))
        transaction_type = request.form.get('type', 'transfer')

        if transaction_type == 'transfer':
            transaction = TransactionService.transfer_funds(
                current_user.user_id,
                from_account,
                to_account,
                amount
            )
        else:
            transaction = TransactionService.create_deposit(
                current_user.user_id,
                to_account,
                amount
            )

        if request.is_json:
            return jsonify(transaction.to_dict()), 201
        flash('Transaction created successfully', 'success')
        return redirect(url_for('transactions.get_transactions'))
    except Exception as e:
        logger.error(f"Failed to create transaction: {str(e)}")
        if request.is_json:
            return jsonify({'error': str(e)}), 500
        flash(str(e), 'danger')
        return redirect(url_for('transactions.get_transactions'))

@transactions_bp.route('/<transaction_id>', methods=['GET'])
@login_required
def get_transaction_details(transaction_id):
    try:
        transaction = TransactionService.get_transaction_details(
            current_user.user_id,
            transaction_id
        )
        if request.is_json:
            return jsonify(transaction.to_dict()), 200
        return render_template('transaction_details.html', transaction=transaction)
    except Exception as e:
        if request.is_json:
            return jsonify({'error': str(e)}), 500
        flash('Unable to load transaction details', 'danger')
        return redirect(url_for('transactions.get_transactions'))
